#ROASASS 
#RecordsOfAkashia 

***[Platform Foundation will need to be something like this:

Tables+Dataset_Connectors

Google_Earth_Platform + Unreal_Engine + Open_Source + Elements+
(Some sort of software that combines elements like Cell to Singletary or Perhaps just find images to represent real life elements in hyper-realistic formats. So convert all basic Elements into 3d vr format. Then use Ai to Start building those elements one by one attached to each label in files in multiple_clouds_table_datasets? Sql? idk)

While Hyper Earth is being created. We can also Creat Characters based off of the exact same methods but starting with cells and also using Pattern recognition techniques to build character features. Medical research datasets to cross analyze medical conditions, tics, temperaments etc.

We can also conduct a new Ai study. The study will be a brand new personality analysis in humans showing what people focus on the most in life and how their minds work in general. I'm shooting for a 16Personalities/Big5/DarkTriad-ish Overall Global Assessment. 

Results will help guide users to their best formulated "project choices","careers ideas". Perhaps the titles of these categories in themselves will be based off character analysis. 

Judging in Character confidence factors in some catered terminologies vs Harsh Mode...this is healing platform. Every single option is only an option. 
Genomes can be opted out of in Test Mode or Set to Private Accounts. etc. 

No one will be forced to participate in any activities that they are not interested in. The entire focal point...should be considered what makes people happier by building on their own interests and skill sets. Allowing them opportunities to utilize what they love to do. In Education, In advertising, in development Etc etc etc


[Human_Anatomy_Database+ Unreal_Engine +Character_Design(?) 

<Genome database +AI+ Psychology+ Cognitive_Functions>]

This is Basically where I am at thus far. 

I Have Tons of Implementations I want to incorporate later on. Such as catering to different industries. I was VR realtors. VR Art Galleries. VR Concerts and Auditions for Artist Competitions. I would like to have Marketing And advertising show clothes on people in real life "dressing rooms" and have options to call mom or sis to verify whether it's a suitable look on you or not. 

CRYPTO currencies are a must and I want to utilize the blockchain for contributing each development.] ***




