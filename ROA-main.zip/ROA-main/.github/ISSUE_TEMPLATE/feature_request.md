---
[<Name><Feature request>
<About><Suggest an idea for this project>
<Title><'R-O-A_Records_Of_Akashia'>
<Labels><'Open_Source,Hyper-realistic,Tables,Datasets,Database-Connectors, Elements,Unreal_Engine,Adobe,Google,VR,3D,Cognitive_Functions,Psychology
<Assignees><julymoon87+josmarketplace><At beginning Stages, I am recruiting select few developers for my team. Once I've laid out our Foundation and get the Project started for our community Phase'>]

******Is your feature request related to a problem? Please describe.** The feature is meant as an concise and easy way to help teach people how to respect others in fighting to stand against social stigmas. It's meant to help us understand perspectives and utilize each others views in order to solve bigger problems as a whole. 

*******A clear and concise description of what the problem is. Ex.- I'm always frustrated when [I realize how much I dont know about developing software and I feel I'm very obviously winging this project Solo]

******Describe the solution you'd like**
A clear and concise description of what you want to happen. Refer to the rest of my rants below. 

******Describe alternatives you've considered**
A clear and concise description of any alternative solutions or features you've considered. 

*******Below is what I have written down so far. 

*******Platform Foundation will need to be something like this:

Tables+[Dataset_Connectors]

Google_Earth_Platform + Unreal_Engine + Open_Source + Elements+
(Some sort of software that combines elements like Cell to Singletary or Perhaps just find images to represent real life elements in hyper-realistic formats. So convert all basic Elements into 3d vr format. Then use Ai to Start building those elements one by one attached to each label in files in multiple_clouds_table_datasets? Sql? idk)

While Hyper Earth is being created. We can also Creat Characters based off of the exact same methods but starting with cells and also using Pattern recognition techniques to build character features. Medical research datasets to cross analyze medical conditions, tics, temperaments etc.

We can also conduct a new Ai study. The study will be a brand new personality analysis in humans showing what people focus on the most in life and how their minds work in general. I'm shooting for a 16Personalities/Big5/DarkTriad-ish Overall Global Assessment. 

Results will help guide users to their best formulated "project choices","careers ideas". Perhaps the titles of these categories in themselves will be based off character analysis. 

Judging in Character confidence factors in some catered terminologies vs Harsh Mode...this is healing platform. Every single option is only an option. 
Genomes can be opted out of in Test Mode or Set to Private Accounts. etc. 

No one will be forced to participate in any activities that they are not interested in. The entire focal point...should be considered what makes people happier by building on their own interests and skill sets. Allowing them opportunities to utilize what they love to do. In Education, In advertising, in development Etc etc etc

[Human_Anatomy_Database+ Unreal_Engine +Character_Design(?) 

<Genome database +AI+ Psychology+ Cognitive_Functions>]

This is Basically where I am at thus far. 

I Have Tons of Implementations I want to incorporate later on. Such as catering to different industries. I was VR realtors. VR Art Galleries. VR Concerts and Auditions for Artist Competitions. I would like to have Marketing And advertising show clothes on people in real life "dressing rooms" and have options to call mom or sis to verify whether it's a suitable look on you or not. 

CRYPTO currencies are a must and I want to utilize the blockchain for contributing each development. 

I have another side project I need developed Separately from R.O.A.

I know I had some other ideas for this, but I'm blanking out right now.  I'll come back and list more thoughts in an updated white page. This is my scratch paper.

**Additional context** This is a Perspectives Platform meant to help earth find some healing. In this day and age... social stigmas are a huge issue that has damaged so many of our lives feeling as if we had nothing to offer. 
The entire point of this Project is to deploy the S.A.S.S. Movement that Jo's Marketplace LLC is Pledging to the world. Standing Against Social Stigmas has become my biggest passion and only concern I personally have as a person. 

Please keep in mind that, this Platform will be presented as a research and educational platform as well and it's extremely important that all Code and Data be 100% Factual and in accuracies. Heights, weights, elemental compounds, Everything will be dependent upon the Hyper-realistic scale and detail of this platform. Think DaVinci. I'm OCD and everything will have to be re-evaluated 2 or 3x for accuracies. (It's in the name of science....please 😶😔)

Add any other context or screenshots about the feature request here.

😮‍💨😏j********